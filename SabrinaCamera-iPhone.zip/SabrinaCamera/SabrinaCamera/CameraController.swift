import AVFoundation
import Photos
import SwiftUI

@MainActor
final class CameraController: NSObject, ObservableObject {
    @Published var mode: CaptureMode = .video
    @Published var settings = CameraSettings()
    @Published var isRecording = false
    @Published var status = ""
    @Published var availableLenses: [AVCaptureDevice.DeviceType] = []
    @Published var selectedLens: AVCaptureDevice.DeviceType = .builtInWideAngleCamera

    let session = AVCaptureSession()
    private let queue = DispatchQueue(label: "camera.session", qos: .userInitiated)
    private let photoOutput = AVCapturePhotoOutput()
    private let movieOutput = AVCaptureMovieFileOutput()
    private var videoInput: AVCaptureDeviceInput?
    private var audioInput: AVCaptureDeviceInput?

    override init() {
        super.init()
        discoverLenses()
    }

    func requestAccessAndStart() async {
        let camera = await AVCaptureDevice.requestAccess(for: .video)
        let microphone = await AVCaptureDevice.requestAccess(for: .audio)
        guard camera else { status = "Autorize o acesso à câmera nos Ajustes."; return }
        if !microphone { status = "O vídeo será gravado sem áudio até o microfone ser autorizado." }
        configureSession(includeAudio: microphone)
    }

    private func discoverLenses() {
        let types: [AVCaptureDevice.DeviceType] = [.builtInUltraWideCamera, .builtInWideAngleCamera, .builtInTelephotoCamera, .builtInTrueDepthCamera]
        availableLenses = types.filter { AVCaptureDevice.default($0, for: .video, position: $0 == .builtInTrueDepthCamera ? .front : .back) != nil }
    }

    func configureSession(includeAudio: Bool = true) {
        let lens = selectedLens
        queue.async { [weak self] in
            guard let self else { return }
            session.beginConfiguration()
            session.sessionPreset = .inputPriority
            session.inputs.forEach(session.removeInput)
            session.outputs.forEach(session.removeOutput)

            let position: AVCaptureDevice.Position = lens == .builtInTrueDepthCamera ? .front : .back
            guard let device = AVCaptureDevice.default(lens, for: .video, position: position),
                  let input = try? AVCaptureDeviceInput(device: device), session.canAddInput(input) else {
                session.commitConfiguration()
                Task { @MainActor in self.status = "Esta lente não está disponível." }
                return
            }
            session.addInput(input)
            videoInput = input

            if includeAudio, let microphone = AVCaptureDevice.default(for: .audio),
               let input = try? AVCaptureDeviceInput(device: microphone), session.canAddInput(input) {
                session.addInput(input); audioInput = input
            }
            if session.canAddOutput(photoOutput) {
                session.addOutput(photoOutput)
                photoOutput.maxPhotoQualityPrioritization = .speed
                photoOutput.isResponsiveCaptureEnabled = photoOutput.isResponsiveCaptureSupported
                photoOutput.isFastCapturePrioritizationEnabled = photoOutput.isFastCapturePrioritizationSupported
            }
            if session.canAddOutput(movieOutput) { session.addOutput(movieOutput) }
            session.commitConfiguration()
            applyCurrentSettings()
            if !session.isRunning { session.startRunning() }
        }
    }

    func changeLens(_ lens: AVCaptureDevice.DeviceType) {
        selectedLens = lens
        configureSession()
    }

    func applyCurrentSettings() {
        let snapshot = settings
        let selectedMode = mode
        queue.async { [weak self] in
            guard let self, let device = videoInput?.device else { return }
            do {
                try device.lockForConfiguration()
                defer { device.unlockForConfiguration() }

                let requestedFPS = selectedMode == .slowMotion ? max(120, snapshot.fps) : snapshot.fps
                if let format = bestFormat(device: device, dimensions: snapshot.resolution.dimensions, fps: requestedFPS) {
                    device.activeFormat = format
                    let duration = CMTime(value: 1, timescale: CMTimeScale(requestedFPS))
                    device.activeVideoMinFrameDuration = duration
                    device.activeVideoMaxFrameDuration = duration
                }
                if snapshot.manualExposure {
                    let duration = CMTime(seconds: snapshot.shutterSeconds, preferredTimescale: 1_000_000_000)
                    let iso = min(max(snapshot.iso, device.activeFormat.minISO), device.activeFormat.maxISO)
                    if device.isExposureModeSupported(.custom) { device.setExposureModeCustom(duration: duration, iso: iso) }
                } else if device.isExposureModeSupported(.continuousAutoExposure) {
                    device.exposureMode = .continuousAutoExposure
                    device.setExposureTargetBias(min(max(snapshot.exposureBias, device.minExposureTargetBias), device.maxExposureTargetBias))
                }
                if snapshot.manualFocus, device.isFocusModeSupported(.locked) {
                    device.setFocusModeLocked(lensPosition: snapshot.focus)
                } else if device.isFocusModeSupported(.continuousAutoFocus) { device.focusMode = .continuousAutoFocus }

                if device.isWhiteBalanceModeSupported(.locked) {
                    let temp = AVCaptureDevice.WhiteBalanceTemperatureAndTintValues(temperature: snapshot.whiteBalanceKelvin, tint: 0)
                    var gains = device.deviceWhiteBalanceGains(for: temp)
                    gains.redGain = min(max(1, gains.redGain), device.maxWhiteBalanceGain)
                    gains.greenGain = min(max(1, gains.greenGain), device.maxWhiteBalanceGain)
                    gains.blueGain = min(max(1, gains.blueGain), device.maxWhiteBalanceGain)
                    device.setWhiteBalanceModeLocked(with: gains)
                }
                configureConnections(stabilization: snapshot.stabilization)
            } catch { Task { @MainActor in self.status = "Não foi possível aplicar essa configuração." } }
        }
    }

    private func bestFormat(device: AVCaptureDevice, dimensions: CMVideoDimensions, fps: Int) -> AVCaptureDevice.Format? {
        device.formats.filter { format in
            let d = CMVideoFormatDescriptionGetDimensions(format.formatDescription)
            return d.width == dimensions.width && d.height == dimensions.height &&
                format.videoSupportedFrameRateRanges.contains { $0.maxFrameRate >= Double(fps) }
        }.max { a, b in
            CMVideoFormatDescriptionGetDimensions(a.formatDescription).width < CMVideoFormatDescriptionGetDimensions(b.formatDescription).width
        }
    }

    private func configureConnections(stabilization: Bool) {
        [movieOutput.connection(with: .video), photoOutput.connection(with: .video)].compactMap { $0 }.forEach { connection in
            if connection.isVideoStabilizationSupported { connection.preferredVideoStabilizationMode = stabilization ? .standard : .off }
        }
    }

    func triggerCapture() {
        mode.recordsVideo ? toggleRecording() : takePhoto()
    }

    private func takePhoto() {
        var photoSettings: AVCapturePhotoSettings
        if settings.rawPhoto, let rawType = photoOutput.availableRawPhotoPixelFormatTypes.first {
            photoSettings = AVCapturePhotoSettings(rawPixelFormatType: rawType)
        } else {
            let codec: AVVideoCodecType = photoOutput.availablePhotoCodecTypes.contains(.hevc) ? .hevc : .jpeg
            photoSettings = AVCapturePhotoSettings(format: [AVVideoCodecKey: codec])
        }
        photoSettings.photoQualityPrioritization = .speed
        photoSettings.isAutoStillImageStabilizationEnabled = false
        photoSettings.flashMode = .off
        if mode == .portrait && photoOutput.isDepthDataDeliverySupported {
            photoOutput.isDepthDataDeliveryEnabled = true
            photoSettings.isDepthDataDeliveryEnabled = true
            photoSettings.embedsDepthDataInPhoto = true
        }
        photoOutput.capturePhoto(with: photoSettings, delegate: self)
    }

    private func toggleRecording() {
        if movieOutput.isRecording { movieOutput.stopRecording(); return }
        let ext = settings.codec == .h264 ? "mp4" : "mov"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathExtension(ext)
        if let connection = movieOutput.connection(with: .video), movieOutput.availableVideoCodecTypes.contains(settings.codec.avCodec) {
            movieOutput.setOutputSettings([AVVideoCodecKey: settings.codec.avCodec], for: connection)
        }
        movieOutput.startRecording(to: url, recordingDelegate: self)
        isRecording = true
    }

    private func saveToPhotos(_ url: URL) {
        PHPhotoLibrary.requestAuthorization(for: .addOnly) { authorization in
            guard authorization == .authorized || authorization == .limited else {
                Task { @MainActor in self.status = "Autorize o acesso à Fototeca para salvar." }; return
            }
            PHPhotoLibrary.shared().performChanges({ PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url) }) { success, _ in
                Task { @MainActor in self.status = success ? "Vídeo salvo e pronto para postar." : "Não foi possível salvar o vídeo." }
                try? FileManager.default.removeItem(at: url)
            }
        }
    }
}

extension CameraController: AVCapturePhotoCaptureDelegate {
    nonisolated func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        guard error == nil, let data = photo.fileDataRepresentation() else { return }
        PHPhotoLibrary.requestAuthorization(for: .addOnly) { authorization in
            guard authorization == .authorized || authorization == .limited else { return }
            PHPhotoLibrary.shared().performChanges({
                let request = PHAssetCreationRequest.forAsset()
                request.addResource(with: .photo, data: data, options: nil)
            }) { success, _ in Task { @MainActor in self.status = success ? "Foto salva." : "Não foi possível salvar a foto." } }
        }
    }
}

extension CameraController: AVCaptureFileOutputRecordingDelegate {
    nonisolated func fileOutput(_ output: AVCaptureFileOutput, didStartRecordingTo fileURL: URL, from connections: [AVCaptureConnection]) {
        Task { @MainActor in self.isRecording = true }
    }
    nonisolated func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        Task { @MainActor in
            self.isRecording = false
            if error == nil { self.saveToPhotos(outputFileURL) } else { self.status = "A gravação falhou." }
        }
    }
}

