import SwiftUI

@main
struct SabrinaCameraApp: App {
    var body: some Scene {
        WindowGroup { CameraScreen() }
    }
}

