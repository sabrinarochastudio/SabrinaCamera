# Próximas etapas para uma versão de produção

1. Validar em um iPhone 15 quais combinações de lente, resolução, codec e FPS são expostas pelo aparelho.
2. Trocar a gravação simples por `AVAssetWriter` para controle detalhado de bitrate, áudio, metadados e orientação.
3. Implementar histograma, zebras, false color, focus peaking e LUTs no preview com Metal, sem gravar esses elementos no arquivo.
4. Criar presets para Stories: 1080 × 1920, 30/60 fps e clipes com duração configurável.
5. Adicionar indicador de áudio, armazenamento restante, timecode, nomes de arquivo e gravação externa.
6. Testar interrupções, ligações, superaquecimento, pouco armazenamento e troca de lente durante gravação.
7. Fazer testes visuais comparando HEVC, ProRes, RAW e câmera nativa antes de publicar na App Store.

