# Sabrina Camera

Aplicativo de câmera profissional para iPhone, feito em SwiftUI e AVFoundation.

## Objetivo

Capturar fotos e vídeos com controle manual e disponibilizar o arquivo assim que a captura termina. O app evita filtros próprios e desativa, quando a API pública permite, HDR automático, estabilização cinematográfica, priorização de qualidade e processamento adicional de foto.

## Limitações do iOS

- Apps de terceiros não conseguem desligar todo o processamento computacional embutido no pipeline da câmera do iPhone.
- A captura RAW/DNG é a opção com menor interferência disponível para fotos, quando suportada pela lente ativa.
- O modo Cinema da Apple e seu mapa de profundidade editável não estão disponíveis integralmente para captura por APIs públicas. O modo `CINEMA` deste app é um preset de vídeo com controles manuais.
- ProRes, RAW, profundidade, lentes, taxas de quadro e resoluções dependem do modelo e da câmera selecionada.

## Como abrir

1. Em um Mac, instale o Xcode.
2. Abra `SabrinaCamera.xcodeproj`.
3. Selecione sua equipe em Signing & Capabilities.
4. Rode em um iPhone físico. O simulador não reproduz as câmeras do aparelho.

O arquivo `project.yml` também está incluído para quem preferir regenerar o projeto com XcodeGen.

O alvo mínimo está em iOS 17 para usar APIs públicas estáveis. Ele também pode ser compilado para SDKs posteriores; se o Xcode apresentar `iOS 27.0` como SDK disponível, basta selecioná-lo.
