import SwiftUI
import AVFoundation

struct CameraScreen: View {
    @StateObject private var camera = CameraController()
    @State private var showControls = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            CameraPreview(session: camera.session).ignoresSafeArea()
            gridOverlay
            VStack(spacing: 0) {
                topBar
                Spacer()
                if !camera.status.isEmpty { Text(camera.status).font(.caption).padding(8).background(.black.opacity(0.7)).clipShape(Capsule()) }
                lensBar.padding(.vertical, 10)
                modeBar
                shutterBar.padding(.vertical, 18)
            }.foregroundStyle(.white)
        }
        .task { await camera.requestAccessAndStart() }
        .sheet(isPresented: $showControls) { ProfessionalControls(camera: camera) }
        .preferredColorScheme(.dark)
    }

    private var topBar: some View {
        HStack {
            Button { camera.settings.grid = camera.settings.grid == .off ? .thirds : .off } label: { Image(systemName: "grid") }
            Spacer()
            Text("\(camera.settings.resolution.rawValue)  •  \(camera.mode == .slowMotion ? max(120, camera.settings.fps) : camera.settings.fps) FPS").font(.system(.caption, design: .monospaced).weight(.semibold))
            Spacer()
            Button { showControls = true } label: { Image(systemName: "slider.horizontal.3") }
        }.padding().background(.black.opacity(0.42))
    }

    private var lensBar: some View {
        HStack(spacing: 12) {
            ForEach(camera.availableLenses, id: \.rawValue) { lens in
                Button(lensTitle(lens)) { camera.changeLens(lens) }
                    .font(.caption.bold()).frame(width: 42, height: 32)
                    .background(camera.selectedLens == lens ? Color.yellow : Color.black.opacity(0.55))
                    .foregroundStyle(camera.selectedLens == lens ? .black : .white).clipShape(Capsule())
            }
        }
    }

    private var modeBar: some View {
        ScrollViewReader { proxy in
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 22) {
                    ForEach(CaptureMode.allCases) { mode in
                        Button(mode.rawValue) { camera.mode = mode; camera.applyCurrentSettings(); withAnimation { proxy.scrollTo(mode.id, anchor: .center) } }
                            .font(.caption.bold()).foregroundStyle(camera.mode == mode ? .yellow : .white).id(mode.id)
                    }
                }.padding(.horizontal, 60)
            }.onAppear { proxy.scrollTo(camera.mode.id, anchor: .center) }
        }
    }

    private var shutterBar: some View {
        HStack {
            Spacer()
            Button(action: camera.triggerCapture) {
                ZStack {
                    Circle().stroke(.white, lineWidth: 4).frame(width: 72, height: 72)
                    if camera.mode.recordsVideo {
                        RoundedRectangle(cornerRadius: camera.isRecording ? 7 : 30).fill(.red).frame(width: camera.isRecording ? 30 : 58, height: camera.isRecording ? 30 : 58)
                    } else { Circle().fill(.white).frame(width: 60, height: 60) }
                }
            }
            Spacer()
        }.background(.black.opacity(0.45))
    }

    @ViewBuilder private var gridOverlay: some View {
        if camera.settings.grid != .off {
            GeometryReader { geo in
                Path { p in
                    let w = geo.size.width, h = geo.size.height
                    if camera.settings.grid == .thirds {
                        p.move(to: .init(x: w/3, y: 0)); p.addLine(to: .init(x: w/3, y: h)); p.move(to: .init(x: 2*w/3, y: 0)); p.addLine(to: .init(x: 2*w/3, y: h))
                        p.move(to: .init(x: 0, y: h/3)); p.addLine(to: .init(x: w, y: h/3)); p.move(to: .init(x: 0, y: 2*h/3)); p.addLine(to: .init(x: w, y: 2*h/3))
                    }
                }.stroke(.white.opacity(0.35), lineWidth: 0.6)
            }.allowsHitTesting(false)
        }
    }

    private func lensTitle(_ lens: AVCaptureDevice.DeviceType) -> String {
        switch lens { case .builtInUltraWideCamera: return "0,5×"; case .builtInTelephotoCamera: return "3×"; case .builtInTrueDepthCamera: return "↺"; default: return "1×" }
    }
}

struct ProfessionalControls: View {
    @ObservedObject var camera: CameraController
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("Gravação") {
                    Picker("Resolução", selection: $camera.settings.resolution) { ForEach(VideoResolution.allCases) { Text($0.rawValue).tag($0) } }
                    Picker("Codec", selection: $camera.settings.codec) { ForEach(VideoCodec.allCases) { Text($0.rawValue).tag($0) } }
                    Picker("Quadros por segundo", selection: $camera.settings.fps) { ForEach([24,25,30,50,60,120,240], id: \.self) { Text("\($0) FPS").tag($0) } }
                    Toggle("Estabilização", isOn: $camera.settings.stabilization)
                }
                Section("Exposição") {
                    Toggle("Exposição manual", isOn: $camera.settings.manualExposure)
                    if camera.settings.manualExposure {
                        ValueSlider(title: "ISO", value: $camera.settings.iso, range: 25...2000, format: "%.0f")
                        ValueSlider(title: "Obturador (1/x)", value: Binding(get: { Float(1 / camera.settings.shutterSeconds) }, set: { camera.settings.shutterSeconds = 1 / Double($0) }), range: 24...1000, format: "%.0f")
                    } else { ValueSlider(title: "Compensação EV", value: $camera.settings.exposureBias, range: -3...3, format: "%+.1f") }
                }
                Section("Foco e cor") {
                    Toggle("Foco manual", isOn: $camera.settings.manualFocus)
                    if camera.settings.manualFocus { ValueSlider(title: "Foco", value: $camera.settings.focus, range: 0...1, format: "%.2f") }
                    ValueSlider(title: "Temperatura (K)", value: $camera.settings.whiteBalanceKelvin, range: 2500...10000, format: "%.0f")
                }
                Section("Foto") { Toggle("RAW/DNG quando disponível", isOn: $camera.settings.rawPhoto) }
                Section("Assistência") {
                    Picker("Grade", selection: $camera.settings.grid) { ForEach(GridStyle.allCases) { Text($0.rawValue).tag($0) } }
                    Toggle("Histograma", isOn: $camera.settings.histogram)
                    Toggle("Zebras", isOn: $camera.settings.zebras)
                    Text("Histograma e zebras estão preparados na interface, mas precisam do pipeline Metal para análise ao vivo.").font(.caption).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Controles")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Aplicar") { camera.applyCurrentSettings(); dismiss() } } }
        }
    }
}

private struct ValueSlider: View {
    let title: String
    @Binding var value: Float
    let range: ClosedRange<Float>
    let format: String
    var body: some View {
        VStack(alignment: .leading) {
            HStack { Text(title); Spacer(); Text(String(format: format, value)).monospacedDigit().foregroundStyle(.secondary) }
            Slider(value: $value, in: range)
        }
    }
}

