import AVFoundation

enum CaptureMode: String, CaseIterable, Identifiable {
    case slowMotion = "CÂMERA LENTA"
    case cinema = "CINEMA"
    case video = "VÍDEO"
    case photo = "FOTO"
    case portrait = "RETRATO"
    var id: String { rawValue }
    var recordsVideo: Bool { self == .slowMotion || self == .cinema || self == .video }
}

enum VideoResolution: String, CaseIterable, Identifiable {
    case hd = "1080p", ultraHD = "4K"
    var id: String { rawValue }
    var dimensions: CMVideoDimensions {
        self == .ultraHD ? .init(width: 3840, height: 2160) : .init(width: 1920, height: 1080)
    }
}

enum VideoCodec: String, CaseIterable, Identifiable {
    case hevc = "HEVC", h264 = "H.264", proRes = "ProRes"
    var id: String { rawValue }
    var avCodec: AVVideoCodecType {
        switch self {
        case .hevc: return .hevc
        case .h264: return .h264
        case .proRes: return .proRes422
        }
    }
}

enum GridStyle: String, CaseIterable, Identifiable {
    case off = "Desligada", thirds = "Terços", square = "Quadrada"
    var id: String { rawValue }
}

struct CameraSettings {
    var resolution: VideoResolution = .ultraHD
    var codec: VideoCodec = .hevc
    var fps: Int = 30
    var iso: Float = 100
    var shutterSeconds: Double = 1.0 / 60.0
    var exposureBias: Float = 0
    var whiteBalanceKelvin: Float = 5600
    var manualExposure = false
    var manualFocus = false
    var focus: Float = 0.5
    var stabilization = true
    var rawPhoto = false
    var grid: GridStyle = .thirds
    var histogram = false
    var zebras = false
}

